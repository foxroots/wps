
| Questions         | Answers
| ----------------- | -------------------------------------------------------
| Description?      | Please describe your changes as much as possible.
| Type?             | bug fix / improvement / new feature / refacto
| Fixed ticket?     | Issue link here <!--- MAKE SURE THAT ISSUE EXISTS BEFORE SUBMITTING PULL REQUEST --->

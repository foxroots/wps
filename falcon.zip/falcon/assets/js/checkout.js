(()=>{(()=>{"use strict";var c={};(()=>{c.n=o=>{var e=o&&o.__esModule?()=>o.default:()=>o;return c.d(e,{a:e}),e}})(),(()=>{c.d=(o,e)=>{for(var l in e)c.o(e,l)&&!c.o(o,l)&&Object.defineProperty(o,l,{enumerable:!0,get:e[l]})}})(),(()=>{c.o=(o,e)=>Object.prototype.hasOwnProperty.call(o,e)})();var d={};(()=>{const o=jQuery;var e=c.n(o);const l=prestashop;var r=c.n(l);/**
 * 2007-2017 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2017 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */function s(){e()(r().themeSelectors.checkout.termsLink).on("click",t=>{t.preventDefault();let n=e()(t.target).attr("href");n&&(n+="?content_only=1",e().get(n,a=>{e()(r().themeSelectors.modal).find(r().themeSelectors.modalContent).html(e()(a).find(".page-cms").contents())}).fail(a=>{r().emit("handleError",{eventType:"clickTerms",resp:a})})),e()(r().themeSelectors.modal).modal("show")}),e()(r().themeSelectors.checkout.giftCheckbox).on("click",()=>{e()("#gift").slideToggle()})}e()(document).ready(()=>{e()("body#checkout").length===1&&s(),r().on("updatedDeliveryForm",t=>{typeof t.deliveryOption=="undefined"||t.deliveryOption.length===0||(e()(r().themeSelectors.checkout.carrierExtraContent).hide(),t.deliveryOption.next(r().themeSelectors.checkout.carrierExtraContent).slideDown())}),r().on("changedCheckoutStep",t=>{typeof t.event.currentTarget!="undefined"&&e()(".collapse",t.event.currentTarget).not(".show").not(".collapse .collapse").collapse("show")})}),e()(document).on("change",'.checkout-option input[type="radio"]',t=>{const a=e()(t.currentTarget).closest(".checkout-option");a.parent().find(".checkout-option").removeClass("selected"),a.addClass("selected")}),e()(document).on("click",".js-checkout-step-header",t=>{const n=e()(t.currentTarget).data("identifier");e()(`#${n}`).addClass("-current"),e()(`#content-${n}`).collapse("show").scrollTop()})})(),(()=>{})()})();})();
